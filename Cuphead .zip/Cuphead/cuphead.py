import pygame
from pygame.locals import *
import random
import sys
import time
import unittest

pygame.init()

class GameObject(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        pygame.sprite.Sprite.__init__(self)
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Player(GameObject):
    def __init__(self, x, y, image):
        super().__init__(x, y, image)
        self.lives = 3
        self.score = 0
        self.image_angle = 0

    def update(self):
        rotated_image = pygame.transform.rotate(self.image, self.image_angle)
        self.rect = rotated_image.get_rect(center=self.rect.center)
        return rotated_image

# Define the timer decorator
def timer(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        print(f"Execution time of {func.__name__}: {end_time - start_time} seconds")
        return result
    return wrapper

Player.update = timer(Player.update)

class Bullet(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, pygame.Surface((10, 5)))  # Create a simple rectangular bullet
        self.image.fill((0, 255, 255))  # Fill the bullet surface with color
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.radius = 5

    def update(self):
        self.rect.x += 2

class Enemy(GameObject):
    def __init__(self, x, y, image):
        super().__init__(x, y, image)

    def update(self):
        self.rect.x -= 2

class BlueEnemy(Enemy):
    def __init__(self, x, y, image):
        super().__init__(x, y, image)

class GreenEnemy(Enemy):
    def __init__(self, x, y, image):
        super().__init__(x, y, image)

class RedEnemy(Enemy):
    def __init__(self, x, y, image):
        super().__init__(x, y, image)

class EnemyFactory:
    @staticmethod
    def create_enemy(x, y, color, image):
        if color == 'blue':
            return BlueEnemy(x, y, image)
        elif color == 'green':
            return GreenEnemy(x, y, image)
        elif color == 'red':
            return RedEnemy(x, y, image)
        else:
            raise ValueError("Invalid enemy color")

class FlyingEnemy(Enemy):
    def __init__(self, enemy):
        super().__init__(enemy.rect.x, enemy.rect.y, enemy.image)
        self.enemy = enemy

    def update(self):
        self.enemy.rect.y += random.choice([-1, 0, 1])  # Randomize vertical movement

class Game:
    def __init__(self):
        self.game_width = 800
        self.game_height = 500
        self.screen_size = (self.game_width, self.game_height)
        self.game_window = pygame.display.set_mode(self.screen_size)
        pygame.display.set_caption('Cuphead')
        self.padding_y = 50
        self.clock = pygame.time.Clock()
        self.fps = 120
        self.running = True
        self.bullet_cooldown = 500
        self.last_bullet_time = pygame.time.get_ticks()
        self.next_enemy_time = pygame.time.get_ticks()
        self.bg_scroll = 0
        self.start_menu = True  # Start with the start menu
        self.font = pygame.font.Font(pygame.font.get_default_font(), 32)
        self.game_over_time = None

    def load_images(self):
        airplane_image = pygame.transform.scale(pygame.image.load('images/fly.png').convert_alpha(), (70, 70))
        heart_image = pygame.transform.scale(pygame.image.load('images/heart.png').convert_alpha(), (30, 30))  # Load a  heart image
        enemy_images = {
            'blue': pygame.transform.flip(pygame.transform.scale(pygame.image.load('images/blue.png').convert_alpha(), (80,80)), True, False),
            'green': pygame.transform.flip(pygame.transform.scale(pygame.image.load('images/green.png').convert_alpha(), (80, 80)), True, False),
            'red': pygame.transform.flip(pygame.transform.scale(pygame.image.load('images/red.png').convert_alpha(), (85, 50)), True, False)
        }
        bg = pygame.transform.scale(pygame.image.load('images/bg.png').convert_alpha(), (self.game_width, self.game_height))
        start_menu_bg = pygame.transform.scale(pygame.image.load('images/bg1.jpg').convert_alpha(), self.screen_size)  # Load start menu background
        return airplane_image, heart_image, enemy_images, bg, start_menu_bg

    def handle_collisions(self, player, bullet_group, enemy_group):
        for enemy in pygame.sprite.spritecollide(player, enemy_group, True):
            player.lives -= 1

        for bullet in bullet_group:
            enemy_hit_list = pygame.sprite.spritecollide(bullet, enemy_group, True)
            for enemy in enemy_hit_list:
                bullet_group.remove(bullet)
                bullet.kill()
                player.score += 1

    def start_menu_loop(self):
        airplane_image, heart_image, enemy_images, bg, start_menu_bg = self.load_images()  # Load images
        play_text = self.font.render('Play', True, (255, 255, 255))
        highscore_text = self.font.render('Highscore', True, (255, 255, 255))
        play_rect = play_text.get_rect(center=(self.game_width // 2, self.game_height // 2 - 30))
        highscore_rect = highscore_text.get_rect(center=(self.game_width // 2, self.game_height // 2 + 30))

        while self.start_menu:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if play_rect.collidepoint(mouse_pos):
                        self.start_menu = False
                        return "play"
                    elif highscore_rect.collidepoint(mouse_pos):
                        self.display_highscores()

            self.game_window.blit(start_menu_bg, (0, 0))  # Blit start menu background
            self.game_window.blit(play_text, play_rect)
            self.game_window.blit(highscore_text, highscore_rect)
            pygame.display.update()

    def save_highscores(self, score):
        with open("score.txt", "a") as file:
            file.write(str(score) + "\n")

    def display_highscores(self):
        self.game_window.fill((0, 0, 0))  # Fill the screen with black
        font = pygame.font.Font(pygame.font.get_default_font(), 32)
        title_text = font.render('Highscores', True, (255, 255, 255))
        title_rect = title_text.get_rect(center=(self.game_width // 2, 50))
        self.game_window.blit(title_text, title_rect)

        scores = []
        try:
            with open("score.txt", "r") as file:
                scores = [int(score.strip()) for score in file.readlines()]
        except FileNotFoundError:
            pass

        scores.sort(reverse=True)
        scores = scores[:10]

        y = 100
        for i, score in enumerate(scores):
            score_text = font.render(f'{i+1}. {score}', True, (255, 255, 255))
            score_rect = score_text.get_rect(center=(self.game_width // 2, y))
            self.game_window.blit(score_text, score_rect)
            y += 40

        pygame.display.update()
        time.sleep(3)
        self.start_menu_loop()

    def run(self):
        airplane_image, heart_image, enemy_images, bg, _ = self.load_images()  # Load images and ignore start menu bg
        player = Player(30, self.game_height // 2, airplane_image)
        player_group = pygame.sprite.Group(player)
        bullet_group = pygame.sprite.Group()
        enemy_group = pygame.sprite.Group()

        # Start menu loop
        self.start_menu_loop()

        while self.running:
            self.clock.tick(self.fps)
    
            for event in pygame.event.get():
                if event.type == QUIT:
                    self.running = False

            keys = pygame.key.get_pressed()

            if keys[pygame.K_w] and player.rect.top > self.padding_y:
                player.rect.y -= 2
                player.image_angle = 15
            elif keys[pygame.K_s] and player.rect.bottom < self.game_height - self.padding_y:
                player.rect.y += 2
                player.image_angle = -15
            else:
                player.image_angle = 0

            if keys[pygame.K_SPACE] and pygame.time.get_ticks() - self.last_bullet_time > self.bullet_cooldown:
                bullet = Bullet(player.rect.x + player.rect.width, player.rect.centery) # Create a simple rectangular bullet
                bullet_group.add(bullet)
                self.last_bullet_time = pygame.time.get_ticks()

            if pygame.time.get_ticks() > self.next_enemy_time:
                color = random.choice(list(enemy_images.keys()))
                enemy = EnemyFactory.create_enemy(self.game_width, random.randint(self.padding_y, self.game_height - self.padding_y * 2), color, enemy_images[color])
                if color == 'blue':
                    enemy = FlyingEnemy(enemy)
                enemy_group.add(enemy)
                self.next_enemy_time = pygame.time.get_ticks() + random.randint(0, 2000)

            self.handle_collisions(player, bullet_group, enemy_group)

            self.game_window.blit(bg, (0 - self.bg_scroll, 0))
            self.game_window.blit(bg, (self.game_width - self.bg_scroll, 0))
            self.bg_scroll = (self.bg_scroll + 1) % self.game_width

            player_image = player.update()
            self.game_window.blit(player_image, player.rect)

            bullet_group.update()
            bullet_group.draw(self.game_window)

            enemy_group.update()
            enemy_group.draw(self.game_window)

            for enemy in enemy_group:
                if enemy.rect.right < 0:  # Check if enemy goes off-screen
                    player.lives -= 1
                    enemy.kill()  # Remove the enemy sprite when it goes off-screen

            for i in range(player.lives):
                self.game_window.blit(heart_image, (10 + i * (heart_image.get_width() + 10), 10))  # Blit the single heart image multiple times based on player's lives

            font = pygame.font.Font(pygame.font.get_default_font(), 16)
            text = font.render(f'Score: {player.score}', True, (255, 105, 180))
            text_rect = text.get_rect(center=(200, 20))
            self.game_window.blit(text, text_rect)

            pygame.display.update()

            if player.lives == 0:
                self.running = False
                self.save_highscores(player.score)
                self.game_over_time = time.time()
                self.show_game_over_screen()

    def show_game_over_screen(self):
        game_over = True
        while game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            if self.game_over_time is not None and time.time() - self.game_over_time > 3:
                self.start_menu_loop()

            self.game_window.fill((0, 0, 0))  # Fill the screen with black
            try:
                custom_game_over_image = pygame.image.load("images/game_over.jpg").convert_alpha()
                game_over_rect = custom_game_over_image.get_rect(center=(self.game_width // 2, self.game_height // 2))
                self.game_window.blit(custom_game_over_image, game_over_rect)
            except pygame.error as e:
                print("Error loading custom game over image:", e)
                font = pygame.font.Font(pygame.font.get_default_font(), 32)
                game_over_text = font.render('Game Over', True, (255, 105, 180))
                game_over_rect = game_over_text.get_rect(center=(self.game_width // 2, self.game_height // 2))
                self.game_window.blit(game_over_text, game_over_rect)
            pygame.display.update()

class TestCuphead(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.game = Game()

    def tearDown(self):
        pygame.quit()

    def test_enemy_factory(self):
        enemy = EnemyFactory.create_enemy(100, 100, 'blue', pygame.Surface((80, 80)))
        self.assertIsInstance(enemy, BlueEnemy)

if __name__ == "__main__":
    game = Game()
    game.run()
