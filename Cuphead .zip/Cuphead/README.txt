In order for this game to work put the folder images into 
(This PC > Local Disk > Users > User)  User folder, or where the terminal asks you to put it